package mx.com.fractalyst.pocs.springbootholamundo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbHolaMundoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbHolaMundoApplication.class, args);
	}

}
