package mx.com.fractalyst.pocs.springbootholamundo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbHolaMundoApplicationTests {

	@Test
	void contextLoads() {
	}

}
